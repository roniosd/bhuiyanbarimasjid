<x-app-layout title="Member List">
    <div class="content-area">
        <div class="row">
            <div class="">
                <div class="content-inner">
                    <div class="custom-card p-1">
                        <div class="custom-card-header ">

                            <div class="heading">

                                <h1>User Feedback</h1>
                            </div>

                        </div>
                        <div class="container py-4">
                            <div class="card shadow-sm border-0">


                                <div class="card-body p-0">
                                    @if ($feedbacks->count())
                                        <div class="table-responsive">
                                            <table id="adminTable"
                                                class="table align-middle table-hover text-left table-striped">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Name</th>
                                                        <th>Email</th>
                                                        <th>Subject</th>
                                                        <th>Message</th>
                                                        <th style="width: 100px">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @foreach ($feedbacks as $index => $feedback)
                                                        <tr>
                                                            <td>{{ $index + 1 }}</td>
                                                            <td>{{ $feedback->name }}</td>
                                                            <td>{{ $feedback->email }}</td>
                                                            <td>{{ $feedback->subject }}</td>
                                                            <td>
                                                                {{ $feedback->shortText($feedback->message, 100) }}
                                                            </td>
                                                            <td>

                                                                <div class="d-flex justify-content-center gap-4">

                                                                    <form title="Delete"
                                                                        action="{{ route('feedback', $feedback->id) }}"
                                                                        method="POST"
                                                                        onsubmit="return confirm('Are you sure you want to delete this fund?');">
                                                                        @csrf
                                                                        @method('DELETE')
                                                                        <button class="delete-btn border-0"
                                                                            type="submit">
                                                                            <svg width="16" height="20"
                                                                                viewBox="0 0 16 20" fill="none"
                                                                                xmlns="http://www.w3.org/2000/svg">
                                                                                <path
                                                                                    d="M6 0L5 1H0V3H1V18C1 19.0931 1.90694 20 3 20H13C14.0931 20 15 19.0931 15 18V3H16V1H14H11L10 0H6ZM3 3H13V18H3V3ZM5.70703 6.29297L4.29297 7.70703L6.58594 10L4.29297 12.293L5.70703 13.707L8 11.4141L10.293 13.707L11.707 12.293L9.41406 10L11.707 7.70703L10.293 6.29297L8 8.58594L5.70703 6.29297Z"
                                                                                    fill="red" />
                                                                            </svg>
                                                                        </button>
                                                                    </form>
                                                                </div>

                                                                @if (strlen($feedback->message) > 100)
                                                                    <a data-bs-toggle="modal"
                                                                        data-bs-target="#feedbackModal{{ $feedback->id }}"
                                                                        class="text-success text-center"
                                                                        href="#">see
                                                                        more</a>
                                                                @endif
                                                            </td>
                                                            <!-- Modal -->
                                                            <div class="modal fade"
                                                                id="feedbackModal{{ $feedback->id }}" tabindex="-1"
                                                                aria-labelledby="feedbackModalLabel{{ $feedback->id }}"
                                                                aria-hidden="true">
                                                                <div class="modal-dialog modal-dialog-centered">
                                                                    <div class="modal-content">
                                                                        <div class="modal-header">
                                                                            <h5 class="modal-title"
                                                                                id="feedbackModalLabel{{ $feedback->id }}">
                                                                                Feedback from
                                                                                {{ $feedback->name }}
                                                                            </h5>
                                                                            <button type="button" class="btn-close"
                                                                                data-bs-dismiss="modal"
                                                                                aria-label="Close"></button>
                                                                        </div>
                                                                        <div class="modal-body">
                                                                            {{ $feedback->message }}
                                                                        </div>
                                                                        <div class="modal-footer">
                                                                            <button type="button"
                                                                                class="btn btn-secondary"
                                                                                data-bs-dismiss="modal">Close</button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    @else
                                        <div class="p-4 text-center text-muted">
                                            <i class="bi bi-info-circle me-1"></i> No feedback found.
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>



                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
