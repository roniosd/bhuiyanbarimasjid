<x-app-layout title="Add post">
    <div class="content-area">
        <form action="{{ route('post.update', $post->id) }}" method="POST" enctype="multipart/form-data"
            class="row theme-form">
            @csrf
            @method('PUT')
            <div class="col-xxl-9 col-xl-8 col-lg-8">
                <div class="content-inner">
                    <div class="custom-card">

                        <div class="custom-card-header">
                            <div class="heading">

                                <h1>Update Post</h1>
                            </div>
                            <div class="header-rigth">
                                <p>Fields marked with * must be filled</p>
                            </div>
                            <div class="seeAll">
                                <a href="{{ route('post.index') }}">See All</a>
                            </div>
                        </div>
                        <div class="custom-card-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group custom-form-group">
                                        <label for="">Enter Post Title</label>
                                        <input type="text" value="{{ $post->title }}" id="Title" name="title"
                                            class="form-control" placeholder="Enter post title">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group custom-form-group">
                                        <label for="">Enter Slug</label>
                                        <input type="text" value="{{ $post->slug }}" id="unique_url" name="slug"
                                            class="form-control" placeholder="Enter slug">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group custom-form-group">
                                        <label for="">Enter Post Subtitle</label>
                                        <input type="text" value="{{ $post->subtitle }}" name="subtitle"
                                            class="form-control" placeholder="Enter post subtitle">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group custom-form-group">
                                        <label for="">Type</label>
                                        <select name="type" id="" class="form-control">
                                            <option value="">Choose Category Type</option>
                                            @foreach (['post', 'news', 'event'] as $type)
                                                <option {{ old('type', $post->type) == $type ? 'selected' : '' }}
                                                    class="text-capitalize" value="{{ $type }}">
                                                    {{ $type }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group custom-form-group">
                                        <label for="">News Type</label>
                                        <select name="news_type" id="" class="form-control">
                                            <option value="">Choose News Type</option>
                                            @foreach (['sticky', 'breaking', 'featured'] as $type)
                                                <option
                                                    {{ old('news_type', $post->news_type) == $type ? 'selected' : '' }}
                                                    class="text-capitalize" value="{{ $type }}">
                                                    {{ $type }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="form-group custom-form-group">
                                        <label for="">Enter Attachment</label>
                                        <input type="text" value="{{ $post->attachment }}" name="attachment"
                                            class="form-control" placeholder="Enter attachment">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group custom-form-group">
                                        <label for="">Enter Excerpt</label>
                                        <input type="text" value="{{ $post->excerpt }}" name="excerpt"
                                            class="form-control" placeholder="Enter excerpt">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group custom-form-group">
                                        <label for="">Enter Tags</label>
                                        <input type="text" value="{{ $post->tags }}" name="tags"
                                            class="form-control" placeholder="Enter tags">
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="form-group custom-form-group">
                                        <label for="">Category</label>
                                        <select name="category_id" id="" class="form-control">
                                            <option value="">Choose Category</option>
                                            @foreach ($categories as $category)
                                                <option
                                                    {{ old('category_id', $post->category->name) == $category->name ? 'selected' : '' }}
                                                    class="capitalize" value="{{ $category->id }}">
                                                    {{ $category->name }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="form-group custom-form-group">
                                        <label for="">Author</label>
                                        <select name="author" id="" class="form-control">
                                            <option value="">Choose author</option>
                                            @foreach ($admins as $admin)
                                                <option
                                                    {{ old('author', $post->authored->full_name) == $admin->full_name ? 'selected' : '' }}
                                                    class="capitalize" value="{{ $admin->id }}">
                                                    {{ $admin->full_name }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form-group custom-form-group">
                                        <label for="">Short Description</label>
                                        <textarea class="form-control lh-lg" style="resize: none;" placeholder="Write a short descriptions"
                                            name="short_description" rows="2" id="">{{ $post->short_description }}</textarea>
                                    </div>
                                </div>

                            </div>
                            <div class="form-group custom-form-group">
                                <textarea placeholder="Post descriptions" name="description" id="editor">{{ $post->description }}</textarea>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="col-xxl-3 col-xl-4 col-lg-4">
                <div class="sidebar-widgets">
                    <div class="custom-card" style="padding:0;background: none;box-shadow: none;">
                        <div class="custom-card-body">
                            <div class="form-group custom-form-group">
                                <label for="">Select Status</label>
                                <select name="status" id="" class="form-control">
                                    <option value="">Select one</option>
                                    <option {{ old('status', $post->status) == 'published' ? 'selected' : '' }}
                                        value="published">Published</option>
                                    <option {{ old('status', $post->status) == 'unpublished' ? 'selected' : '' }}
                                        value="unpublished">Unpublished</option>
                                </select>
                            </div>

                            <x-admin.upload-image name='photo' title='Post Image' size='512 X 512px'
                                :img="'post/' . $post->photo" />
                            <button type="submit" class="btn theme-btn">
                                <i class="bi bi-plus-circle-dotted me-3"></i>
                                Update Post
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</x-app-layout>
