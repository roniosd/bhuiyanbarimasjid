<x-app-layout title="Update Collector">
    <div class="content-area">


        <form action="{{ route('collector.update', $collector->id) }}" method="POST" enctype="multipart/form-data"
            class="row ">
            @csrf
            @method('PUT')
            <div class="content-inner col-xxl-9 col-xl-8 col-lg-8">
                <div class="custom-card">
                    <div class="custom-card-header">
                        <div class="heading">
                            <h1>Update collector</h1>
                        </div>
                        <div class="header-rigth">
                            <p>Fields marked with * must be filled</p>
                        </div>
                        <div class="seeAll">
                            <a href="{{ route('collector.index') }}">See All</a>
                        </div>
                    </div>

                    <div class="custom-card-body">
                        <div class="row">

                            <div class="col-lg-4">
                                <div class="form-group custom-form-group">
                                    <label for="">Name</label>
                                    <input type="text" name="name" class="form-control" placeholder="Enter Name"
                                        value="{{ old('name', $collector->name) }}">
                                </div>
                            </div>


                            <div class="col-lg-4">
                                <div class="form-group custom-form-group">
                                    <label for="">Mobile number</label>
                                    <input type="text" name="mobile_number" class="form-control"
                                        placeholder="Enter mobile number"
                                        value="{{ old('mobile_number', $collector->mobile_number) }}">
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="form-group custom-form-group">
                                    <label for="">Nid</label>
                                    <input type="text" name="nid" class="form-control" placeholder="Enter nid"
                                        value="{{ old('nid', $collector->nid) }}">
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="form-group custom-form-group">
                                    <label for="">aAppointed By</label>
                                    <input type="text" name="appointed_by" class="form-control"
                                        placeholder="Ex: Roni"
                                        value="{{ old('appointed_by', $collector->appointed_by) }}">
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xxl-3 col-xl-4 col-lg-4">
                <div class="sidebar-widgets">
                    <x-admin.upload-image name="photo" title="Collector Image" size="2020 X 650px"
                        :img="'collector/' . $collector->photo" />


                    <button type="submit" class="btn theme-btn ms-2">
                        <i class="bi bi-plus-circle-dotted me-3"></i>
                        Update Collector
                    </button>
                </div>
            </div>
        </form>

    </div>
</x-app-layout>
