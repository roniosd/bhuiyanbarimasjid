<x-app-layout title="Add post">
    <div class="content-area text-gray-900 text-base">
        <form action="{{ route('post.store') }}" method="POST" enctype="multipart/form-data" class="row theme-form">
            @csrf
            <div class="col-xxl-9 col-xl-8 col-lg-8">
                <div class="content-inner">
                    <div class="custom-card ">
                        <div class="custom-card-header ">

                            <div class="heading">

                                <h1>Add Post</h1>
                            </div>
                            <div class="header-rigth">
                                <p>Fields marked with * must be filled</p>
                            </div>
                            <div class="seeAll">
                                <a href="{{ route('post.index') }}">See All</a>
                            </div>
                        </div>

                        <div class="custom-card-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group custom-form-group">
                                        <label>Enter Post Title</label>
                                        <input type="text" name="title" value="{{ old('title') }}"
                                            class="form-control" placeholder="Enter post title">
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="form-group custom-form-group">
                                        <label>Enter Slug</label>
                                        <input type="text" name="slug" value="{{ old('slug') }}"
                                            class="form-control" placeholder="Enter slug">
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="form-group custom-form-group">
                                        <label>Enter Post Subtitle</label>
                                        <input type="text" name="subtitle" value="{{ old('subtitle') }}"
                                            class="form-control" placeholder="Enter post subtitle">
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="form-group custom-form-group">
                                        <label>Type</label>
                                        <select name="type" class="form-control">
                                            <option value="">Choose Category Type</option>
                                            <option value="post" {{ old('type') == 'post' ? 'selected' : '' }}>
                                                Post
                                            </option>
                                            <option value="news" {{ old('type') == 'news' ? 'selected' : '' }}>
                                                News
                                            </option>
                                            <option value="event" {{ old('type') == 'event' ? 'selected' : '' }}>
                                                Event
                                            </option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="form-group custom-form-group">
                                        <label>News Type</label>
                                        <select name="news_type" class="form-control">
                                            <option value="">Choose News Type</option>
                                            <option value="sticky" {{ old('news_type') == 'sticky' ? 'selected' : '' }}>
                                                Sticky</option>
                                            <option value="breaking"
                                                {{ old('news_type') == 'breaking' ? 'selected' : '' }}>Breaking
                                            </option>
                                            <option value="featured"
                                                {{ old('news_type') == 'featured' ? 'selected' : '' }}>Featured
                                            </option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="form-group custom-form-group">
                                        <label>Enter Attachment</label>
                                        <input type="text" name="attachment" value="{{ old('attachment') }}"
                                            class="form-control" placeholder="Enter attachment">
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="form-group custom-form-group">
                                        <label>Enter Excerpt</label>
                                        <input type="text" name="excerpt" value="{{ old('excerpt') }}"
                                            class="form-control" placeholder="Enter excerpt">
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="form-group custom-form-group">
                                        <label>Enter Tags</label>
                                        <input type="text" name="tags" value="{{ old('tags') }}"
                                            class="form-control" placeholder="Enter tags">
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="form-group custom-form-group">
                                        <label>Category</label>
                                        <select name="category_id" class="form-control">
                                            <option value="">Choose Category</option>
                                            @foreach ($categories as $category)
                                                <option value="{{ $category->id }}"
                                                    {{ old('category_id') == $category->id ? 'selected' : '' }}>
                                                    {{ $category->name }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="form-group custom-form-group">
                                        <label>Author</label>
                                        <select name="author" class="form-control">
                                            <option value="">Choose author</option>
                                            @foreach ($admins as $admin)
                                                <option value="{{ $admin->id }}"
                                                    {{ old('author') == $admin->id ? 'selected' : '' }}>
                                                    {{ $admin->full_name }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="form-group custom-form-group">
                                        <label>Short Description</label>
                                        <textarea class="form-control lh-lg" style="resize: none;" placeholder="Write a short description"
                                            name="short_description" rows="2">{{ old('short_description') }}</textarea>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group custom-form-group">
                                <textarea placeholder="Post descriptions" name="description" id="editor">{{ old('description') }}</textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xxl-3 col-xl-4 col-lg-4">
                <div class="sidebar-widgets">
                    <div class="custom-card" style="padding:0;background: none;box-shadow: none;">
                        <div class="custom-card-body">
                            <div class="form-group custom-form-group">
                                <label>Select Status</label>
                                <select name="status" class="form-control">
                                    <option value="">Select one</option>
                                    <option value="published" {{ old('status') == 'published' ? 'selected' : '' }}>
                                        Published</option>
                                    <option value="unpublished"
                                        {{ old('status') == 'unpublished' ? 'selected' : '' }}>
                                        Unpublished</option>
                                </select>
                            </div>

                            <x-admin.upload-image name='photo' title='Post Image' size='512 X 512px' />

                            <button type="submit" class="btn theme-btn mt-3">
                                <i class="bi bi-plus-circle-dotted me-3"></i>
                                Add Post
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</x-app-layout>
